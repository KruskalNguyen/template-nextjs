
## [2.2.0] 2024-02-06

### Next 14

## [2.1.0] 2023-11-10

### Bug fix - Build error due to Types

- Updated types
- Updated charts 
## [2.0.0] 2023-09-13 

### Big update - NextJS 13 Update

- Layouts update 
- Updated routing
- Updated image component
- Updated link component

## [1.0.1] 2022-03-22
### Bug Fixing 
Auth layout fixed
## [1.0.0] 2022-10-17

### Original Release
- Added Typescript & NextJS